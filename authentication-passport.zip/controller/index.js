const express = require('express');
const router = express.Router();

router.get('/test-1', (req, res) => res.json({status: '( :  1'}));
router.get('/test-2', (req, res) => res.json({status: '( :  2'}));
router.get('/test-3', (req, res) => res.json({status: '( :  3'}));

module.exports = router;