const express = require('express');
const router = express.Router();
const passport = require('passport');

router.post('/login', passport.authenticate('local', {
    successRedirect: '/welcome.html',
    failureRedirect: '/login.html'
}));

router.get('/logout', (req, res, next) => {
    req.logout();
    res.sendStatus(200);
});

module.exports = router;